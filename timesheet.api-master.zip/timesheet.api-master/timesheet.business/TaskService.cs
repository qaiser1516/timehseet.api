﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using timesheet.business.Interfaces;
using timesheet.data;
using timesheet.model;

namespace timesheet.business
{
    public class TaskService: ITaskService
    {
        private TimesheetDb _db { get; }
        public TaskService(TimesheetDb dbContext)
        {
           _db = dbContext;
        }

        public IQueryable<Task> GetTasks()
        {
            return _db.Tasks;
        }
    }
}

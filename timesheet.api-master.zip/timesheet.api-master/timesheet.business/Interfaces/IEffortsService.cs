﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using timesheet.model;

namespace timesheet.business.Interfaces
{
    public interface IEffortsService
    {
        IQueryable<Efforts> GetEfforts();

        IQueryable<Efforts> GetEffortByEmployee(int employeeId);

        void AddEfforts(Efforts effort);

        void AddMultipleEfforts(List<Efforts> efforts);
    }
}

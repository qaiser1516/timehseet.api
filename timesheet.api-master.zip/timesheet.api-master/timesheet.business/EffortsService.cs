﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using timesheet.business.Interfaces;
using timesheet.data;
using timesheet.model;

namespace timesheet.business
{
    public class EffortsService : IEffortsService
    {
        private TimesheetDb _db { get; }
        public EffortsService(TimesheetDb timesheetDb)
        {
            _db = timesheetDb;
        }

        public IQueryable<Efforts> GetEfforts()
        {
            int weekNum = GetWeekNo();

            return _db.Efforts.Where(o => o.WeekNo == weekNum);
        }

        public IQueryable<Efforts> GetEffortByEmployee(int employeeId)
        {
            int weekNum = GetWeekNo();

            return _db.Efforts.Where(ef => ef.EmployeeId == employeeId && ef.WeekNo == weekNum);
        }        

        public void AddEfforts(Efforts effort)
        {
            _db.Efforts.Add(effort);
            _db.SaveChanges();
        }

        public void AddMultipleEfforts(List<Efforts> efforts)
        {
            _db.Efforts.AddRange(efforts);
        }

        private static int GetWeekNo()
        {
            DateTime date = DateTime.Now;
            CultureInfo cul = CultureInfo.CurrentCulture;

            int weekNum = cul.Calendar.GetWeekOfYear(
                date,
                CalendarWeekRule.FirstDay,
                DayOfWeek.Monday);
            return weekNum;
        }
    }
}

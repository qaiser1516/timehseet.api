﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Configuration;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
namespace timesheet.model
{
    public class Efforts
    {
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        [Key]
        public int Id { get; set; }

        [Required]
        public int TaskId { get; set; }

        [Required]
        public int EmployeeId { get; set; }

        [Required]
        public int WeekNo { get; set; }

        [Range(0,24)]
        public int MondayHours { get; set; } = 0;

        [Range(0, 24)]
        public int TuesdayHours { get; set; } = 0;

        [Range(0, 24)]
        public int WednesdayHours { get; set; } = 0;

        [Range(0, 24)]
        public int ThursdayHours { get; set; } = 0;

        [Range(0, 24)]
        public int FridayHours { get; set; } = 0;

        [Range(0, 24)]
        public int SaturdayHours { get; set; } = 0;

        [Range(0, 24)]
        public int SundayHours { get; set; } = 0;

        public virtual Employee Employee { get; set; }
       
        public virtual Task Task { get; set; }

    }
}

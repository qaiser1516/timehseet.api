﻿using System;
using System.Collections.Generic;
using System.Text;

namespace timesheet.model.ViewModel
{
    public class EffortsViewModel
    {
        public int TaskId { get; set; }

        public int EmployeeId { get; set; }

        public int MondayHours { get; set; } = 0;

        public int TuesdayHours { get; set; } = 0;

        public int WednesdayHours { get; set; } = 0;

        public int ThursdayHours { get; set; } = 0;

        public int FridayHours { get; set; } = 0;

        public int SaturdayHours { get; set; } = 0;

        public int SundayHours { get; set; } = 0;
    }
}

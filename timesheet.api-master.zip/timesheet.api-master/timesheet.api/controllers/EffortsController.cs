﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using timesheet.business.Interfaces;
using timesheet.model;
using timesheet.model.ViewModel;

namespace timesheet.api.controllers
{
    [ApiController]
    [Route("/api/v1/efforts")]
    public class EffortsController : ControllerBase
    {
        private readonly IEffortsService _effortsService;
        public EffortsController(IEffortsService effortsService)
        {
            _effortsService = effortsService;
        }

        [HttpGet("getall")]
        public IActionResult GetAll()
        {
            var efforts = _effortsService.GetEfforts();
            return Ok(efforts);
        }

        [HttpGet("geteffortbyemployee/{employeeId}")]
        public IActionResult GetEffortByEmployee(int employeeId)
        {
            var efforts = _effortsService.GetEffortByEmployee(employeeId);
            return new ObjectResult(efforts.ToList());
        }

        [HttpPost("addeffort")]
        public IActionResult AddEfforts([FromBody] EffortsViewModel effortsViewModel)
        {
            bool success = true;
            if (ModelState.IsValid)
            {
                
                DateTime date = DateTime.Now;
                CultureInfo cul = CultureInfo.CurrentCulture;

                int weekNum = cul.Calendar.GetWeekOfYear(
                    date,
                    CalendarWeekRule.FirstDay,
                    DayOfWeek.Monday);

                try
                {
                    var efforts = new Efforts()
                    {
                        TaskId = effortsViewModel.TaskId,
                        EmployeeId = effortsViewModel.EmployeeId,
                        WeekNo = weekNum,
                        MondayHours = effortsViewModel.MondayHours,
                        TuesdayHours = effortsViewModel.TuesdayHours,
                        WednesdayHours = effortsViewModel.WednesdayHours,
                        ThursdayHours = effortsViewModel.ThursdayHours,
                        FridayHours = effortsViewModel.FridayHours,
                        SaturdayHours = effortsViewModel.SaturdayHours,
                        SundayHours = effortsViewModel.SundayHours,
                    };
                    _effortsService.AddEfforts(efforts);

                }
                catch (Exception ex)
                {
                    success = false;
                }
            }
            else
            {
                success = false;
            }
            return Ok(success);
        }
    }
}
﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using timesheet.business.Interfaces;

namespace timesheet.api.controllers
{
    [ApiController]
    [Route("/api/v1/task")]
    public class TaskController : ControllerBase
    {
        private ITaskService _taskService;

        public TaskController(ITaskService taskService)
        {
            _taskService = taskService;
        }

        [HttpGet("getall")]
        public IActionResult GetAll()
        {
            var tasks = _taskService.GetTasks();
            return new ObjectResult(tasks.ToList());
        }
    }
}